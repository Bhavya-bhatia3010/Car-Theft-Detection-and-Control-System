<img src="./kuqhs41j.png"
style="width:2.11667in;height:3.81667in" />

**<u>MIT APP INVENTOR DESIGN AND CODE</u>**

**<u>App Layout</u>**

**Buttons:**

> o
>
> o
>
> o
>
> o
>
> o

**Start:** Sends the "START" command to the ESP32 web server.

**Stop:** Sends the "STOP" command to the ESP32 web server.

**Update** **Location:** Fetches location from ThingSpeak.

**Show** **Location:** Displays the location on Google Maps using a
WebViewer.

**Refresh:** Resets the app to its initial state.

**Web** **Components:**

> o **Web1:** Fetches GPS data from ThingSpeak.
>
> o **Web2:** Sends "START" and "STOP" commands to the ESP32.

**<u>Designer View</u>**

> **Fig** **1:** **MIN** **Inventor** **Designer** **Window**

<img src="./tzpx1icl.png"
style="width:4.13333in;height:1.28333in" /><img src="./wnciat3k.png" style="width:4.10833in;height:1.2in" /><img src="./eupl5nml.png" style="width:4.99167in;height:1.25in" />

**<u>App Blocks Explanation:</u>**

**Start** **Button:**

> o

**Stop** **Button:**

> o

Sets Web2 URL to /start and triggers the ESP32 server to start the car.

> **Fig** **2:** **MIN** **Inventor** **Start** **Button** **Block**

Sets Web2 URL to /stop and triggers the ESP32 server to stop the car.

> **Fig** **3:** **MIN** **Inventor** **Stop** **Button** **Block**

**Update** **Location** **Button:**

> o Fetches latitude and longitude from ThingSpeak using Web1.
>
> **Fig** **4:** **MIN** **Inventor** **Update** **location** **Button**
> **Block**

<img src="./vimr1aat.png"
style="width:5.95833in;height:2.26667in" /><img src="./hr0hpzo3.png"
style="width:6.26805in;height:4.30694in" />

**View** **Location** **on** **Google** **map** **Button:**

> o Loads Google Maps URL in WebViewer with the latest coordinates.
>
> **Fig** **5:** **MIN** **Inventor** **Location** **on** **Google**
> **map** **Button** **Block**

**Web1** **Code:** **Fetches** **GPS** **data** **from** **ThingSpeak.**

> **Fig** **6:** **MIN** **Inventor** **Web1** **Block**

<img src="./dbov32j5.png"
style="width:3.76667in;height:1.90833in" /><img src="./rneemz35.png"
style="width:4.16667in;height:1.20833in" />

**Web2** **Code:** **Sends** **"START"** **and** **"STOP"** **commands**
**to** **the** **ESP32**

> **Fig** **7:** **MIN** **Inventor** **Web2** **Block**

**Reverse** **Button** **Commands**

> **Fig** **8:** **MIN** **Inventor** **Web2** **Block**

<img src="./yh3t2eru.png"
style="width:6.43083in;height:2.63403in" /><img src="./xubkiyaa.png"
style="width:2.08305in;height:4.40347in" /><img src="./jwxvzivk.png"
style="width:2.08403in;height:4.40625in" />

> **OUTPUT** **AND** **RESULT**
>
> **Fig** **9-** **ThingSpeak** **Output**

**Fig** **10-** **MIT** **APP** **showing** **updated** **location**
**Fig** **11-** **MIT** **APP** **sending** **Start** **command**
